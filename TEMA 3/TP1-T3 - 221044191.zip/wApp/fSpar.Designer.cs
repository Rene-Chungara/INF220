﻿namespace wApp
{
    partial class fSpar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cmdAtoV = new System.Windows.Forms.Button();
            this.cmdProme = new System.Windows.Forms.Button();
            this.lblPTI = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(315, 10);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(64, 19);
            this.button3.TabIndex = 13;
            this.button3.Text = "Mostrar V";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(335, 63);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "...";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(16, 10);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(66, 19);
            this.button2.TabIndex = 11;
            this.button2.Text = "Inicializar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(87, 10);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(66, 19);
            this.button1.TabIndex = 10;
            this.button1.Text = "Mostrar A";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(85, 63);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "...";
            // 
            // cmdAtoV
            // 
            this.cmdAtoV.Location = new System.Drawing.Point(180, 10);
            this.cmdAtoV.Margin = new System.Windows.Forms.Padding(2);
            this.cmdAtoV.Name = "cmdAtoV";
            this.cmdAtoV.Size = new System.Drawing.Size(105, 19);
            this.cmdAtoV.TabIndex = 20;
            this.cmdAtoV.Text = "A[n,m] -->V[c,3]";
            this.cmdAtoV.UseVisualStyleBackColor = true;
            this.cmdAtoV.Click += new System.EventHandler(this.cmdAtoV_Click);
            // 
            // cmdProme
            // 
            this.cmdProme.Location = new System.Drawing.Point(398, 10);
            this.cmdProme.Margin = new System.Windows.Forms.Padding(2);
            this.cmdProme.Name = "cmdProme";
            this.cmdProme.Size = new System.Drawing.Size(70, 19);
            this.cmdProme.TabIndex = 21;
            this.cmdProme.Text = "Suma TI";
            this.cmdProme.UseVisualStyleBackColor = true;
            this.cmdProme.Click += new System.EventHandler(this.cmdProme_Click);
            // 
            // lblPTI
            // 
            this.lblPTI.AutoSize = true;
            this.lblPTI.Location = new System.Drawing.Point(423, 63);
            this.lblPTI.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPTI.Name = "lblPTI";
            this.lblPTI.Size = new System.Drawing.Size(16, 13);
            this.lblPTI.TabIndex = 22;
            this.lblPTI.Text = "...";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(41, 63);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(14, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "A";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(296, 63);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(14, 13);
            this.label6.TabIndex = 25;
            this.label6.Text = "V";
            // 
            // fSpar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(578, 266);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblPTI);
            this.Controls.Add(this.cmdProme);
            this.Controls.Add(this.cmdAtoV);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "fSpar";
            this.Text = "fSpar";
            this.Load += new System.EventHandler(this.fSpar_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button cmdAtoV;
        private System.Windows.Forms.Button cmdProme;
        private System.Windows.Forms.Label lblPTI;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using cApp;

namespace wApp
{
    public partial class fSpar : Form
    {
        public fSpar()
        {
            InitializeComponent();
        }

        int[,] A = { 
                     { 1, 0, 0, 0, 0, 0 }, 
                     { 3, 2, 0, 0, 3, 0 }, 
                     { 0, 0, 0, 0, 0, 0 }, 
                     { 0, 0, 0, 0, 0,-4 }, 
                     { 0,-2, 0, 0, 0, 1 }, 
                     { 0, 0, 0, 0, 1, 0 }, 
                   };

        clsSpar E = new clsSpar();

        private void fSpar_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            label1.Text=E.MostraArreglo(A);
        }


        private void button2_Click_1(object sender, EventArgs e)
         {
            // Se define las caracteristicas de la figura inicial
            E.n = 6;       // Fila de la matriz
            E.m = 6;       // Columna la matriz
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label2.Text = E.MostrarVector();
        }

        private void cmdProme_Click(object sender, EventArgs e)
        {
            lblPTI.Text = E.Suma().ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //lblPTS.Text = E.SumaTS().ToString();
        }

        private void cmdAtoV_Click(object sender, EventArgs e)
        {
            E.CargarMatrizToVector(A);
        }

    }
}

﻿/*************************************************************
Institución:    Universidad Gabriel Rene Moreno
Carrera:        Ingenieria en Sistemas
Materia:        Estructura de Datos I
Proyecto:       clsSpar (Clase Sparce)
Descripción:    Implementacion Suma de dos matrices normales y sparce
Creador:        Rene Eduardo Chungara Martinez
Lenguaje:       C#
Herramienta:    Visual Studio 2019 - Windows Aplications
*************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace cApp
{
    public class clsSpar
    {
         /*ATRIBUTOS*/
       
        const int Max=1000;                         // Maxima Cantidad de elementos en el arreglo V alternativo
        public int[,] V = new int[Max,3];           // Vector donde se almacena los datos de las Matris A original
        public int Cant = 0;                        // Cantidad de celdas llenas en el vector V
        public int n = 0;                           // Cantidad de filas de la Matriz A original
        public int m = 0;                           // Cantidad de columnas de la Matriz A original

        /*CONSTRUCTORES*/
        public clsSpar() 
        { 
            Cant = 0;
            n= 0;
            m = 0;
            int i = 0;
            while (i < Max)
            {
               V[i, 0] = 0;
               V[i, 1] = 0;
               V[i, 2] = 0;  
               i++;
            }
        }
        
        public clsSpar(clsSpar x)
        {
            Cant = x.Cant;
            n = x.n;
            m = x.m;
            int i = 0;  
            while (i < Max)
            {
               V[i, 0] = x.V[i, 0];
               V[i, 1] = x.V[i, 1];
               V[i, 2] = x.V[i, 2];
               i++;
            }
        }

        // Limpiar el Arreglo V 
        public void ClearArreglo()
        {
            int i = 0; Cant = 0;
            while (i < Max)
            {
                V[i, 0] = 0;
                V[i, 1] = 0;
                V[i, 2] = 0;  
                i++;
            }
        }
     
        // Funcion para mostrar la Matriz A 
        public string MostraArreglo(int[,] M)
        {
            int i, j = 0;
            string cad = "";
            for (i = 0; i < n; i++)
            {
                cad += "\n";
                for (j = 0; j < m; j++)
                    cad += "[" + M[i, j] + "]";
            }
            return cad;
        }


 	// Funcion para mostrar Vector V 
        public string MostrarVector()
        {
            string s = "";
            
            for (int i = 0; i < Cant; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                s += " [" + V[i,j] + "]" ; 
                }
                s += "\n";
            }
            return s;
        }

        //Funcion para pasar los datos de la matriz A al vector V
        public void CargarMatrizToVector(int[,] A)
        {
            // dim A
            n = A.GetLength(0); //
            m = A.GetLength(1); //
            V[0, 0] = n;
            V[0, 1] = m;
            Cant = 1;
            // dim A el nro de filas y el nro de columnas 
            int i = 0;
            while (i < n) 
            {
                int j=0;
                while (j < m) 
                {
                    if (A[i,j]!=0)
                    {
                        V[Cant, 0] = i;
                        V[Cant, 1] = j;
                        V[Cant, 2] = A[i, j];
                        Cant++;
                    }
                    j++;
                }
                i++;
            }
            V[0, 2] = Cant;
        }

        // Funcion calcular la sumatoria los elementos mayores a cero que estan en A a partir de V.

        public double Suma()
        {
            double s = 0;

            for (int i = 1; i <= Cant;i++ )
            {
                if (V[i,2]>0)
                {
                    s+=V[i,2];
                }
            }
            return s;
        }
        //suma dos matriz normal
        public int[,] SumaNormal(int[,] A, int[,] B)
        {
            int n1 = A.GetLength(0);
            int m1 = A.GetLength(1);
            int[,] C = new int[n1, m1];
            if (A.GetLength(0) == B.GetLength(0) && A.GetLength(1) == A.GetLength(1))
            {
                for (int i = 0; i < n1; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        C[i, j] = A[i, j] + B[i, j];
                    }
                }
                return C;
            }
            return C;
        }
        //Suma dos Matriz Sparce
        public void sumaSpar(clsSpar A, clsSpar B)
        {
            clsSpar C = new clsSpar();
            if (A.Cant == B.Cant)
            {
                C.V[0, 0] = A.n;
                C.V[0, 1] = A.m;
                C.n = A.n;
                C.m = A.m;
                C.Cant = A.Cant;
                for (int i = 1; i < A.Cant; i++)
                {
                    C.V[i, 2] = A.V[i, 2] + B.V[i, 2];
                }

            }
        }

    }
}
